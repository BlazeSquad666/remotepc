import datetime
import io
import socket
import ctypes
import pyautogui
import tornado.ioloop
import tornado.template
import tornado.web
import tornado.websocket
import subprocess
import time
import requests
import re
import zipfile
import os

# Oculta la consola de Windows


def take_ss():
    byte_arr = io.BytesIO()
    pyautogui.screenshot().save(byte_arr, format='JPEG')
    return byte_arr.getvalue()

def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Conectarse a una IP arbitraria para obtener la IP local
        s.connect(('8.8.8.8', 80))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        loader = tornado.template.Loader(".")
        self.write(loader.load("client/index.html").generate())

class WSHandler(tornado.websocket.WebSocketHandler):
    def open(self):
        prtsc = pyautogui.screenshot()
        self.write_message("size {} {}".format(prtsc.width, prtsc.height))
        self.send_ss()

    def on_message(self, message):
        splitted = message.split(" ")
        if splitted[0] == "key":
            keys = splitted[1:]
            pyautogui.hotkey(*keys)
        elif splitted[0] == "mouse":
            button_mapping = {"0": "left", "1": "right", "2": "middle"}
            button = button_mapping[splitted[1].lower()]
            pyautogui.click(button=button)
        elif splitted[0] == 'move':
            x = float(splitted[1])
            y = float(splitted[2])
            pyautogui.moveTo(x, y)

    def on_close(self):
        pass

    def send_ss(self):
        try:
            self.write_message(take_ss(), binary=True)
            tornado.ioloop.IOLoop.current().add_timeout(datetime.timedelta(milliseconds=50), self.send_ss)
        except KeyboardInterrupt:
            exit()
        except:
            pass

def update_client_url(url):
    with open('client/index.html', 'r') as f:
        html = f.read()
    pattern = r'wss://[a-z0-9]+\.ngrok\.io'
    html = re.sub(pattern, url, html)
    with open('client/index.html', 'w') as f:
        f.write(html)

def make_app():
    return tornado.web.Application([
        (r'/ws', WSHandler),
        (r'/', MainHandler),
        (r"/(.*)", tornado.web.StaticFileHandler, {"path": "./client"}),
    ])

if __name__ == "__main__":
    port_number = 4444
    local_ip = get_local_ip()
    app = make_app()
    app.listen(port_number, address='0.0.0.0')  # Escuchar en todas las interfaces
    print(f"Server running at http://{local_ip}:{port_number}")

    # Configurar ngrok
    if not os.path.exists('ngrok.exe'):
        print('Ngrok no está instalado. Descargando...')
        subprocess.run(['curl', '-s', '-o', 'ngrok.zip', 'https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip'])
        with zipfile.ZipFile('ngrok.zip', 'r') as zip_ref:
            zip_ref.extractall()
        os.remove('ngrok.zip')

    print('Ejecutando ngrok...')
    ngrok_process = subprocess.Popen(['ngrok.exe', 'http', str(port_number)])
    time.sleep(5)  # Esperar a que ngrok se inicialice

    try:
        response = requests.get('http://localhost:4040/api/tunnels')
        ngrok_tunnels = response.json()['tunnels']
        for tunnel in ngrok_tunnels:
            if tunnel['public_url'].startswith('https'):
                ngrok_url = tunnel['public_url'].replace("https", "wss")
                break
        else:
            ngrok_url = None

        if ngrok_url:
            print('URL pública de ngrok:', ngrok_url)
            update_client_url(ngrok_url)
        else:
            print('No se encontró la URL pública de ngrok.')
            ngrok_process.terminate()
            exit(1)
    except requests.exceptions.RequestException as e:
        print('Error al obtener la URL de ngrok:', e)
        ngrok_process.terminate()
        exit(1)

    try:
        tornado.ioloop.IOLoop.instance().start()
    except:
        tornado.ioloop.IOLoop.instance().stop()
